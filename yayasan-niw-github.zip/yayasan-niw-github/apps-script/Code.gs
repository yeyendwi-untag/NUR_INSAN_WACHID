/**
 * BACKEND WEBSITE YAYASAN NUR INSAN WACHID
 * Google Apps Script — data di Google Sheet, file di Google Drive, surat via Gmail.
 * Cara pasang: lihat PANDUAN.md
 */

// ====== PENGATURAN (WAJIB DIISI SEBELUM MENJALANKAN setup) ======
const ROOT_FOLDER_ID = '1oI0oVRJ7dDAwTzy_EGt-QrGOhKcQQ-LC';
const ADMIN_USERNAME = 'yeyendwiaffri.s.st.mt@gmail.com';
const ADMIN_PASSWORD = 'GANTI_DENGAN_PASSWORD_ANDA'; // isi password admin, lalu jalankan setup()
// =================================================================

const SHEETS = {
  Pengurus: ['id', 'nama', 'jabatan', 'urutan', 'telepon', 'email', 'periode', 'foto'],
  Agenda: ['id', 'tanggal', 'judul', 'deskripsi', 'pic', 'lokasi', 'anggaran', 'status'],
  Keuangan: ['id', 'tanggal', 'jenis', 'kategori', 'uraian', 'jumlah', 'bukti', 'dicatat'],
  RAB: ['id', 'tahun', 'bulan', 'program', 'uraian', 'volume', 'satuan', 'harga'],
  SuratMasuk: ['id', 'tanggal_terima', 'tanggal_surat', 'nomor', 'pengirim', 'perihal', 'disposisi', 'status', 'file', 'keterangan'],
  SuratKeluar: ['id', 'tanggal', 'nomor', 'jenis', 'tujuan', 'email', 'perihal', 'isi', 'file', 'lampiran', 'status'],
  Profil: ['kunci', 'nilai'],
  Log: ['waktu', 'aksi', 'detail']
};
const PUBLIC_SHEETS = ['Pengurus', 'Agenda', 'Keuangan', 'RAB'];
const FOLDERS = { SuratMasuk: 'Surat Masuk', SuratKeluar: 'Surat Keluar', Keuangan: 'Bukti Keuangan', Pengurus: 'Foto Pengurus' };
const KODE_SURAT = { Undangan: 'UND', Pemberitahuan: 'PEMB', Permohonan: 'PMH', Keputusan: 'SK', Keterangan: 'KET', Tugas: 'ST', Lainnya: 'UM' };
const TOKEN_TTL = 21600; // 6 jam

// ---------- SETUP (jalankan sekali dari editor) ----------
function setup() {
  const props = PropertiesService.getScriptProperties();
  let ss;
  const id = props.getProperty('SHEET_ID');
  if (id) {
    ss = SpreadsheetApp.openById(id);
  } else {
    ss = SpreadsheetApp.create('Database Yayasan NUR INSAN WACHID');
    DriveApp.getFileById(ss.getId()).moveTo(DriveApp.getFolderById(ROOT_FOLDER_ID));
    props.setProperty('SHEET_ID', ss.getId());
  }
  Object.keys(SHEETS).forEach(function (n) {
    let sh = ss.getSheetByName(n);
    if (!sh) {
      sh = ss.insertSheet(n);
      sh.getRange('A:Z').setNumberFormat('@');
      sh.appendRow(SHEETS[n]);
      sh.setFrozenRows(1);
      sh.getRange(1, 1, 1, SHEETS[n].length).setFontWeight('bold').setBackground('#1a5c3a').setFontColor('#ffffff');
    }
  });
  const s1 = ss.getSheetByName('Sheet1') || ss.getSheetByName('Lembar1');
  if (s1 && ss.getSheets().length > 1) ss.deleteSheet(s1);

  const prof = ss.getSheetByName('Profil');
  if (prof.getLastRow() < 2) {
    [
      ['nama', 'Yayasan NUR INSAN WACHID'], ['singkatan', 'YNIW'], ['tagline', 'Amanah, Transparan, dan Bermanfaat untuk Umat'],
      ['alamat', 'Alamat lengkap yayasan'], ['kota', 'Kota'], ['telepon', '-'], ['email', Session.getEffectiveUser().getEmail()],
      ['akta', 'Nomor akta notaris & SK Kemenkumham'], ['visi', 'Tuliskan visi yayasan di sini.'],
      ['misi', 'Misi pertama\nMisi kedua\nMisi ketiga'], ['sejarah', 'Tuliskan sejarah singkat yayasan.'],
      ['ketua', 'Nama Ketua'], ['sekretaris', 'Nama Sekretaris']
    ].forEach(function (r) { prof.appendRow(r); });
  }
  if (ADMIN_PASSWORD === 'GANTI_DENGAN_PASSWORD_ANDA') throw new Error('Isi ADMIN_PASSWORD terlebih dahulu di baris atas Code.gs');
  props.setProperty('ADMIN_USER', ADMIN_USERNAME.toLowerCase().trim());
  props.setProperty('ADMIN_HASH', hash_(ADMIN_PASSWORD));
  ['SuratMasuk', 'SuratKeluar', 'Keuangan', 'Pengurus'].forEach(function (k) { subFolder_(FOLDERS[k]); });
  Logger.log('SELESAI. Spreadsheet: ' + ss.getUrl());
}

// ---------- HTTP ----------
function doGet(e) {
  try {
    const a = (e.parameter && e.parameter.action) || 'public';
    if (a === 'public') {
      const data = { profil: profil_() };
      PUBLIC_SHEETS.forEach(function (n) { data[n] = rows_(n); });
      return out_({ ok: true, data: data });
    }
    return out_({ ok: false, error: 'Aksi tidak dikenal' });
  } catch (err) { return out_({ ok: false, error: String(err.message || err) }); }
}

function doPost(e) {
  let b;
  try { b = JSON.parse(e.postData.contents); } catch (x) { return out_({ ok: false, error: 'Format data salah' }); }
  try {
    if (b.action === 'login') return out_({ ok: true, data: login_(b.username, b.password) });
    if (!checkToken_(b.token)) return out_({ ok: false, auth: true, error: 'Sesi berakhir, silakan login ulang' });
    const lock = LockService.getScriptLock();
    lock.waitLock(30000);
    try {
      switch (b.action) {
        case 'readAll': {
          const d = { profil: profil_() };
          Object.keys(SHEETS).forEach(function (n) { if (n !== 'Profil' && n !== 'Log') d[n] = rows_(n); });
          return out_({ ok: true, data: d });
        }
        case 'save': return out_({ ok: true, data: save_(b.sheet, b.row || {}, b.file, b.fileField) });
        case 'delete': return out_({ ok: true, data: del_(b.sheet, b.id) });
        case 'saveProfil': return out_({ ok: true, data: saveProfil_(b.data || {}) });
        case 'sendLetter': return out_({ ok: true, data: sendLetter_(b.row || {}, b.file) });
        case 'changePassword': return out_({ ok: true, data: changePass_(b.oldPassword, b.newPassword) });
        case 'logout': CacheService.getScriptCache().remove('tok_' + b.token); return out_({ ok: true, data: true });
        default: return out_({ ok: false, error: 'Aksi tidak dikenal' });
      }
    } finally { lock.releaseLock(); }
  } catch (err) { return out_({ ok: false, error: String(err.message || err) }); }
}

// ---------- AUTH ----------
function hash_(s) {
  const raw = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'niw-salt::' + s, Utilities.Charset.UTF_8);
  return raw.map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}
function login_(u, p) {
  const props = PropertiesService.getScriptProperties();
  if (!u || !p || String(u).toLowerCase().trim() !== props.getProperty('ADMIN_USER') || hash_(p) !== props.getProperty('ADMIN_HASH')) {
    Utilities.sleep(800);
    throw new Error('Username atau password salah');
  }
  const t = Utilities.getUuid() + Utilities.getUuid();
  CacheService.getScriptCache().put('tok_' + t, '1', TOKEN_TTL);
  log_('login', u);
  return { token: t };
}
function checkToken_(t) { return !!t && CacheService.getScriptCache().get('tok_' + t) === '1'; }
function changePass_(oldP, newP) {
  const props = PropertiesService.getScriptProperties();
  if (hash_(oldP || '') !== props.getProperty('ADMIN_HASH')) throw new Error('Password lama salah');
  if (!newP || newP.length < 8) throw new Error('Password baru minimal 8 karakter');
  props.setProperty('ADMIN_HASH', hash_(newP));
  log_('ganti password', '');
  return true;
}

// ---------- DATA ----------
function ss_() { return SpreadsheetApp.openById(PropertiesService.getScriptProperties().getProperty('SHEET_ID')); }
function sheet_(n) {
  if (!SHEETS[n]) throw new Error('Sheet tidak valid: ' + n);
  const sh = ss_().getSheetByName(n);
  if (!sh) throw new Error('Sheet ' + n + ' belum ada, jalankan setup()');
  return sh;
}
function fmt_(x) { return x instanceof Date ? Utilities.formatDate(x, Session.getScriptTimeZone(), 'yyyy-MM-dd') : x; }
function rows_(n) {
  const v = sheet_(n).getDataRange().getValues();
  const h = v.shift();
  return v.filter(function (r) { return r.join('') !== ''; }).map(function (r) {
    const o = {}; h.forEach(function (k, i) { o[k] = fmt_(r[i]); }); return o;
  });
}
function profil_() {
  const o = {}; rows_('Profil').forEach(function (r) { o[r.kunci] = r.nilai; }); return o;
}
function saveProfil_(d) {
  const sh = sheet_('Profil');
  const v = sh.getDataRange().getValues();
  Object.keys(d).forEach(function (k) {
    let found = false;
    for (let i = 1; i < v.length; i++) if (v[i][0] === k) { sh.getRange(i + 1, 2).setValue(String(d[k])); found = true; break; }
    if (!found) sh.appendRow([k, String(d[k])]);
  });
  log_('ubah profil', Object.keys(d).join(','));
  return profil_();
}
function val_(row, k, cur) { return row[k] === undefined || row[k] === null ? cur : String(row[k]); }
function save_(n, row, file, fileField) {
  if (n === 'Profil' || n === 'Log') throw new Error('Tidak diizinkan');
  const sh = sheet_(n), h = SHEETS[n];
  if (file && file.data) row[fileField || 'file'] = upload_(file, FOLDERS[n] || 'Lainnya');
  if (n === 'Keuangan' && !row.id) row.dicatat = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm');
  if (!row.id) {
    row.id = Utilities.getUuid().slice(0, 8);
    sh.appendRow(h.map(function (k) { return val_(row, k, ''); }));
    log_('tambah ' + n, row.id);
  } else {
    const i = findRow_(sh, row.id);
    const cur = sh.getRange(i, 1, 1, h.length).getValues()[0];
    sh.getRange(i, 1, 1, h.length).setValues([h.map(function (k, j) { return val_(row, k, cur[j]); })]);
    log_('ubah ' + n, row.id);
  }
  return row;
}
function findRow_(sh, id) {
  const last = sh.getLastRow();
  if (last < 2) throw new Error('Data tidak ditemukan');
  const ids = sh.getRange(2, 1, last - 1, 1).getValues().map(function (r) { return String(r[0]); });
  const i = ids.indexOf(String(id));
  if (i < 0) throw new Error('Data tidak ditemukan');
  return i + 2;
}
function del_(n, id) {
  if (n === 'Profil' || n === 'Log') throw new Error('Tidak diizinkan');
  const sh = sheet_(n);
  sh.deleteRow(findRow_(sh, id));
  log_('hapus ' + n, id);
  return true;
}
function log_(a, d) { try { sheet_('Log').appendRow([Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'), a, String(d)]); } catch (x) { } }

// ---------- DRIVE ----------
function subFolder_(name) {
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const it = root.getFoldersByName(name);
  return it.hasNext() ? it.next() : root.createFolder(name);
}
function yearFolder_(name) {
  const p = subFolder_(name), y = String(new Date().getFullYear());
  const it = p.getFoldersByName(y);
  return it.hasNext() ? it.next() : p.createFolder(y);
}
function upload_(file, folderName) {
  const blob = Utilities.newBlob(Utilities.base64Decode(file.data), file.mimeType || 'application/octet-stream', file.name || 'file');
  const stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd-HHmmss');
  blob.setName(stamp + '_' + (file.name || 'file'));
  const f = yearFolder_(folderName).createFile(blob);
  f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return 'https://drive.google.com/file/d/' + f.getId() + '/view';
}

// ---------- SURAT KELUAR ----------
const ROMAWI = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
function nomorSurat_(jenis, tgl) {
  const p = profil_(), d = tgl ? new Date(tgl) : new Date(), y = d.getFullYear();
  const count = rows_('SuratKeluar').filter(function (r) { return String(r.tanggal).slice(0, 4) === String(y); }).length + 1;
  return ('00' + count).slice(-3) + '/' + (KODE_SURAT[jenis] || 'UM') + '/' + (p.singkatan || 'YNIW') + '/' + ROMAWI[d.getMonth()] + '/' + y;
}
function esc_(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function tglIndo_(s) {
  const b = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  const d = s ? new Date(s) : new Date();
  return d.getDate() + ' ' + b[d.getMonth()] + ' ' + d.getFullYear();
}
function letterHtml_(r, p) {
  return '<html><body style="font-family:Times New Roman,serif;font-size:12pt;margin:30px 45px;color:#000">' +
    '<div style="text-align:center;border-bottom:3px double #1a5c3a;padding-bottom:8px">' +
    '<div style="font-size:18pt;font-weight:bold;color:#1a5c3a">' + esc_(p.nama) + '</div>' +
    '<div style="font-size:10pt">' + esc_(p.akta) + '</div>' +
    '<div style="font-size:10pt">' + esc_(p.alamat) + ' &middot; Telp. ' + esc_(p.telepon) + ' &middot; ' + esc_(p.email) + '</div></div>' +
    '<table style="margin-top:18px;font-size:12pt"><tr><td style="width:90px">Nomor</td><td>: ' + esc_(r.nomor) + '</td></tr>' +
    '<tr><td>Lampiran</td><td>: ' + (r.lampiran ? '1 (satu) berkas' : '-') + '</td></tr>' +
    '<tr><td>Perihal</td><td>: <b>' + esc_(r.perihal) + '</b></td></tr></table>' +
    '<p style="margin-top:18px">Kepada Yth.<br><b>' + esc_(r.tujuan) + '</b><br>di Tempat</p>' +
    '<p><i>Assalamu\'alaikum Warahmatullahi Wabarakatuh,</i></p>' +
    '<div style="text-align:justify;line-height:1.6">' + esc_(r.isi).replace(/\n/g, '<br>') + '</div>' +
    '<p><i>Wassalamu\'alaikum Warahmatullahi Wabarakatuh.</i></p>' +
    '<table style="width:100%;margin-top:30px"><tr><td style="width:50%;text-align:center">Sekretaris,<br><br><br><br><b><u>' + esc_(p.sekretaris) + '</u></b></td>' +
    '<td style="text-align:center">' + esc_(p.kota) + ', ' + tglIndo_(r.tanggal) + '<br>Ketua,<br><br><br><b><u>' + esc_(p.ketua) + '</u></b></td></tr></table>' +
    '</body></html>';
}
function sendLetter_(row, file) {
  const p = profil_();
  row.tanggal = row.tanggal || Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
  row.jenis = row.jenis || 'Lainnya';
  row.nomor = row.nomor || nomorSurat_(row.jenis, row.tanggal);
  let lampBlob = null;
  if (file && file.data) {
    lampBlob = Utilities.newBlob(Utilities.base64Decode(file.data), file.mimeType, file.name);
    row.lampiran = upload_(file, FOLDERS.SuratKeluar);
  }
  const pdf = HtmlService.createHtmlOutput(letterHtml_(row, p)).getBlob().getAs('application/pdf')
    .setName(row.nomor.replace(/\//g, '-') + ' ' + row.perihal + '.pdf');
  const f = yearFolder_(FOLDERS.SuratKeluar).createFile(pdf);
  f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  row.file = 'https://drive.google.com/file/d/' + f.getId() + '/view';
  row.status = 'Arsip';
  if (row.email && row.kirim !== false) {
    const att = [pdf]; if (lampBlob) att.push(lampBlob);
    MailApp.sendEmail({
      to: row.email, subject: '[' + row.nomor + '] ' + row.perihal, name: p.nama, attachments: att,
      htmlBody: '<p>Kepada Yth. ' + esc_(row.tujuan) + ',</p><p>Bersama email ini kami sampaikan surat resmi dari <b>' + esc_(p.nama) +
        '</b> perihal <b>' + esc_(row.perihal) + '</b> (nomor ' + esc_(row.nomor) + '). Surat terlampir dalam format PDF.</p><p>Hormat kami,<br>' + esc_(p.nama) + '</p>'
    });
    row.status = 'Terkirim';
  }
  delete row.kirim;
  return save_('SuratKeluar', row, null, null);
}

function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
